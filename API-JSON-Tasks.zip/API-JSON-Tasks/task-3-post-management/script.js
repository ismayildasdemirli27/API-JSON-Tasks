const API_URL = "https://jsonplaceholder.typicode.com/posts";

const postForm = document.getElementById("postForm");
const formTitle = document.getElementById("formTitle");
const postIdInput = document.getElementById("postId");
const postTitleInput = document.getElementById("postTitle");
const postBodyInput = document.getElementById("postBody");
const submitBtn = document.getElementById("submitBtn");
const patchTitleBtn = document.getElementById("patchTitleBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");

const reloadBtn = document.getElementById("reloadBtn");
const postCount = document.getElementById("postCount");
const postsList = document.getElementById("postsList");
const statusMessage = document.getElementById("statusMessage");
const alertBox = document.getElementById("alertBox");

let posts = [];
let isEditing = false;

document.addEventListener("DOMContentLoaded", () => {
  fetchPosts();
});

reloadBtn.addEventListener("click", fetchPosts);
postForm.addEventListener("submit", handleFormSubmit);
cancelEditBtn.addEventListener("click", resetForm);
patchTitleBtn.addEventListener("click", handlePatchTitle);

async function fetchPosts() {
  try {
    showLoading("Postlar yüklənir...");
    postsList.innerHTML = "";

    const response = await fetch(`${API_URL}?_limit=10`);

    if (!response.ok) {
      throw new Error(`Server xətası: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    posts = data;
    clearStatus();
    renderPosts();
    showAlert("Postlar uğurla yükləndi!", "success");
  } catch (error) {
    showError(error.message);
    showAlert(`Postları yükləmək mümkün olmadı: ${error.message}`, "error");
  }
}

async function handleFormSubmit(e) {
  e.preventDefault();

  const title = postTitleInput.value.trim();
  const body = postBodyInput.value.trim();

  if (!title || !body) {
    showAlert("Title və Body sahələri boş ola bilməz!", "error");
    return;
  }

  if (isEditing) {
    const id = parseInt(postIdInput.value, 10);
    await updatePostPut(id, title, body);
  } else {
    await createPost(title, body);
  }
}

async function createPost(title, body) {
  try {
    setFormLoading(true, "Yaradılır...");

    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
      body: JSON.stringify({
        title,
        body,
        userId: 1,
      }),
    });

    if (!response.ok) {
      throw new Error(`Xəta: ${response.status} ${response.statusText}`);
    }

    const newPost = await response.json();

    const uniqueId = posts.length > 0 ? Math.max(...posts.map((p) => p.id)) + 1 : 101;
    newPost.id = uniqueId;

    posts.unshift(newPost);
    renderPosts();
    resetForm();
    showAlert("Yeni post uğurla yaradıldı! (POST)", "success");
  } catch (error) {
    showAlert(`Post yaradılarkən xəta: ${error.message}`, "error");
  } finally {
    setFormLoading(false);
  }
}

async function updatePostPut(id, title, body) {
  try {
    setFormLoading(true, "Yenilənir...");

    const response = await fetch(`${API_URL}/${id}`, {
      method: "PUT",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
      body: JSON.stringify({
        id,
        title,
        body,
        userId: 1,
      }),
    });

    if (!response.ok) {
      throw new Error(`Xəta: ${response.status} ${response.statusText}`);
    }

    const updatedData = await response.json();

    posts = posts.map((post) => (post.id === id ? { ...post, title: updatedData.title, body: updatedData.body } : post));
    renderPosts();
    resetForm();
    showAlert(`Post #${id} uğurla yeniləndi! (PUT)`, "success");
  } catch (error) {
    showAlert(`Post yenilənərkən xəta: ${error.message}`, "error");
  } finally {
    setFormLoading(false);
  }
}

async function handlePatchTitle() {
  const id = parseInt(postIdInput.value, 10);
  const title = postTitleInput.value.trim();

  if (!title) {
    showAlert("Yeniləmək üçün Title daxil edin!", "error");
    return;
  }

  try {
    setFormLoading(true, "Yalnız başlıq yenilənir...");

    const response = await fetch(`${API_URL}/${id}`, {
      method: "PATCH",
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
      body: JSON.stringify({
        title,
      }),
    });

    if (!response.ok) {
      throw new Error(`Xəta: ${response.status} ${response.statusText}`);
    }

    const updatedData = await response.json();

    posts = posts.map((post) => (post.id === id ? { ...post, title: updatedData.title } : post));
    renderPosts();
    resetForm();
    showAlert(`Post #${id} başlığı uğurla yeniləndi! (PATCH)`, "success");
  } catch (error) {
    showAlert(`PATCH sorğusu xətası: ${error.message}`, "error");
  } finally {
    setFormLoading(false);
  }
}

async function deletePost(id) {
  const confirmed = window.confirm(`Post #${id} silinsin? Bu əməliyyat geri qaytarılmır.`);
  if (!confirmed) return;

  try {
    showAlert(`Post #${id} silinir...`, "success");

    const response = await fetch(`${API_URL}/${id}`, {
      method: "DELETE",
    });

    if (!response.ok) {
      throw new Error(`Xəta: ${response.status} ${response.statusText}`);
    }

    posts = posts.filter((post) => post.id !== id);
    renderPosts();

    if (isEditing && parseInt(postIdInput.value, 10) === id) {
      resetForm();
    }

    showAlert(`Post #${id} uğurla silindi! (DELETE)`, "success");
  } catch (error) {
    showAlert(`Post silinərkən xəta: ${error.message}`, "error");
  }
}

function renderPosts() {
  postsList.innerHTML = "";
  postCount.textContent = posts.length;

  if (posts.length === 0) {
    postsList.innerHTML = `<p style="text-align: center; color: #718096; padding: 2rem;">Heç bir post tapılmadı.</p>`;
    return;
  }

  posts.forEach((post) => {
    const postEl = document.createElement("div");
    postEl.className = "post-item";
    postEl.dataset.id = post.id;

    postEl.innerHTML = `
      <div class="post-content">
        <span class="post-id-badge">ID: #${post.id}</span>
        <h3 class="post-title">${escapeHtml(post.title)}</h3>
        <p class="post-body">${escapeHtml(post.body)}</p>
      </div>
      <div class="post-actions">
        <button class="btn edit-btn" data-id="${post.id}">Edit</button>
        <button class="btn danger-btn" data-id="${post.id}">Delete</button>
      </div>
    `;

    postEl.querySelector(".edit-btn").addEventListener("click", () => {
      startEditPost(post);
    });

    postEl.querySelector(".danger-btn").addEventListener("click", () => {
      deletePost(post.id);
    });

    postsList.appendChild(postEl);
  });
}

function startEditPost(post) {
  isEditing = true;
  formTitle.textContent = `Postu Redaktə Et #${post.id} (PUT / PATCH)`;
  postIdInput.value = post.id;
  postTitleInput.value = post.title;
  postBodyInput.value = post.body;

  submitBtn.textContent = "Save Changes (PUT)";
  cancelEditBtn.classList.remove("hidden");
  patchTitleBtn.classList.remove("hidden");

  postForm.scrollIntoView({ behavior: "smooth" });
}

function resetForm() {
  isEditing = false;
  formTitle.textContent = "Yeni Post Yarat (POST)";
  postIdInput.value = "";
  postTitleInput.value = "";
  postBodyInput.value = "";

  submitBtn.textContent = "Create Post";
  cancelEditBtn.classList.add("hidden");
  patchTitleBtn.classList.add("hidden");
}

function setFormLoading(loading, message = "") {
  submitBtn.disabled = loading;
  patchTitleBtn.disabled = loading;
  if (loading) {
    submitBtn.textContent = message;
  } else {
    submitBtn.textContent = isEditing ? "Save Changes (PUT)" : "Create Post";
  }
}

let alertTimeout = null;
function showAlert(message, type = "success") {
  clearTimeout(alertTimeout);
  alertBox.className = `alert-box alert-${type}`;
  alertBox.textContent = message;
  alertBox.classList.remove("hidden");

  alertTimeout = setTimeout(() => {
    alertBox.classList.add("hidden");
  }, 4000);
}

function showLoading(text) {
  statusMessage.className = "status-msg loading";
  statusMessage.textContent = text;
}

function showError(text) {
  statusMessage.className = "status-msg error";
  statusMessage.textContent = text;
}

function clearStatus() {
  statusMessage.className = "status-msg";
  statusMessage.textContent = "";
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
