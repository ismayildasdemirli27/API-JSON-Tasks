const BASE_URL = "https://dummyjson.com/products";
const LIMIT = 12;

const searchInput = document.getElementById("searchInput");
const categorySelect = document.getElementById("categorySelect");
const sortSelect = document.getElementById("sortSelect");
const statusMessage = document.getElementById("statusMessage");
const productsGrid = document.getElementById("productsGrid");
const loadMoreBtn = document.getElementById("loadMoreBtn");

const detailsModal = document.getElementById("detailsModal");
const closeModalBtn = document.getElementById("closeModalBtn");
const modalContent = document.getElementById("modalContent");

let currentProducts = [];
let totalProducts = 0;
let currentSkip = 0;
let currentCategory = "";
let searchQuery = "";
let sortMode = "default";
let searchDebounceTimeout = null;

document.addEventListener("DOMContentLoaded", () => {
  fetchCategories();
  loadProducts(true);
});

categorySelect.addEventListener("change", (e) => {
  currentCategory = e.target.value;
  searchInput.value = "";
  searchQuery = "";
  loadProducts(true);
});

searchInput.addEventListener("input", (e) => {
  clearTimeout(searchDebounceTimeout);
  searchDebounceTimeout = setTimeout(() => {
    searchQuery = e.target.value.trim();
    if (searchQuery) {
      currentCategory = "";
      categorySelect.value = "";
    }
    loadProducts(true);
  }, 350);
});

sortSelect.addEventListener("change", (e) => {
  sortMode = e.target.value;
  applySortingAndRender();
});

loadMoreBtn.addEventListener("click", () => {
  loadProducts(false);
});

closeModalBtn.addEventListener("click", closeModal);
detailsModal.addEventListener("click", (e) => {
  if (e.target === detailsModal) closeModal();
});

async function fetchCategories() {
  try {
    const res = await fetch(`${BASE_URL}/categories`);
    if (!res.ok) throw new Error("Kateqoriyaları yükləmək mümkün olmadı");
    const categories = await res.json();

    categories.forEach((cat) => {
      const option = document.createElement("option");
      const slug = typeof cat === "object" ? cat.slug : cat;
      const name = typeof cat === "object" ? cat.name : cat;
      option.value = slug;
      option.textContent = name;
      categorySelect.appendChild(option);
    });
  } catch (err) {
    console.error("Kateqoriya xətası:", err);
  }
}

async function loadProducts(reset = false) {
  try {
    if (reset) {
      currentSkip = 0;
      currentProducts = [];
      productsGrid.innerHTML = "";
      loadMoreBtn.classList.add("hidden");
    }

    showLoading();
    loadMoreBtn.disabled = true;

    let url = "";

    if (searchQuery) {
      url = `${BASE_URL}/search?q=${encodeURIComponent(searchQuery)}&limit=${LIMIT}&skip=${currentSkip}`;
    } else if (currentCategory) {
      url = `${BASE_URL}/category/${encodeURIComponent(currentCategory)}?limit=${LIMIT}&skip=${currentSkip}`;
    } else {
      url = `${BASE_URL}?limit=${LIMIT}&skip=${currentSkip}`;
    }

    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Xəta baş verdi: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    totalProducts = data.total || 0;

    if (reset && (!data.products || data.products.length === 0)) {
      clearStatus();
      showEmptyState("Axtarışa uyğun məhsul tapılmadı.");
      loadMoreBtn.classList.add("hidden");
      return;
    }

    currentProducts = [...currentProducts, ...data.products];
    currentSkip += data.products.length;

    clearStatus();
    applySortingAndRender();

    if (currentProducts.length < totalProducts) {
      loadMoreBtn.classList.remove("hidden");
      loadMoreBtn.disabled = false;
    } else {
      loadMoreBtn.classList.add("hidden");
    }
  } catch (error) {
    showError(error.message);
    loadMoreBtn.classList.add("hidden");
  }
}

function applySortingAndRender() {
  const sorted = [...currentProducts];

  if (sortMode === "price-asc") {
    sorted.sort((a, b) => a.price - b.price);
  } else if (sortMode === "price-desc") {
    sorted.sort((a, b) => b.price - a.price);
  }

  renderProducts(sorted);
}

function renderProducts(products) {
  productsGrid.innerHTML = "";

  products.forEach((product) => {
    const card = document.createElement("div");
    card.className = "product-card";

    const isOutOfStock = product.stock <= 0;
    const stockBadgeClass = isOutOfStock ? "out-of-stock" : "in-stock";
    const stockBadgeText = isOutOfStock ? "Out of Stock" : `Stock: ${product.stock}`;

    card.innerHTML = `
      <div class="image-wrapper">
        <img src="${escapeHtml(product.thumbnail)}" alt="${escapeHtml(product.title)}" class="product-img" loading="lazy">
        <span class="badge-stock ${stockBadgeClass}">${stockBadgeText}</span>
      </div>
      <div class="product-body">
        <span class="product-category">${escapeHtml(product.category)}</span>
        <h3 class="product-title">${escapeHtml(product.title)}</h3>
        <div class="product-meta">
          <span class="product-price">$${product.price}</span>
          <span class="product-rating">⭐ ${product.rating}</span>
        </div>
        <button class="view-btn" data-id="${product.id}">View Details</button>
      </div>
    `;

    card.querySelector(".view-btn").addEventListener("click", () => {
      openDetailsModal(product);
    });

    productsGrid.appendChild(card);
  });
}

function openDetailsModal(product) {
  modalContent.innerHTML = `
    <img src="${escapeHtml(product.thumbnail)}" alt="${escapeHtml(product.title)}" class="modal-image">
    <div class="modal-info">
      <span class="product-category">${escapeHtml(product.category)}</span>
      <h3>${escapeHtml(product.title)}</h3>
      <p>${escapeHtml(product.description || "Təsvir mövcud deyil.")}</p>
      <p><strong>Brand:</strong> ${escapeHtml(product.brand || "Məlum deyil")}</p>
      <p><strong>Qiymət:</strong> <span style="font-size: 1.3rem; color: #2b6cb0; font-weight: bold;">$${product.price}</span> (Endirim: ${product.discountPercentage || 0}%)</p>
      <p><strong>Reytinq:</strong> ⭐ ${product.rating} / 5</p>
      <p><strong>Mövcudluq:</strong> ${product.stock > 0 ? `<span style="color: green;">Stokda var (${product.stock} ədəd)</span>` : '<span style="color: red; font-weight: bold;">Out of Stock</span>'}</p>
    </div>
  `;
  detailsModal.classList.remove("hidden");
}

function closeModal() {
  detailsModal.classList.add("hidden");
}

function showLoading() {
  statusMessage.className = "status-msg loading";
  statusMessage.textContent = "Loading...";
}

function showError(msg) {
  statusMessage.className = "status-msg error";
  statusMessage.textContent = msg;
}

function showEmptyState(msg) {
  statusMessage.className = "status-msg empty";
  statusMessage.textContent = msg;
}

function clearStatus() {
  statusMessage.className = "status-msg";
  statusMessage.textContent = "";
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
