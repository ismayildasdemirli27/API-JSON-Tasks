const API_URL = "https://jsonplaceholder.typicode.com/users";

const loadUsersBtn = document.getElementById("loadUsersBtn");
const sortAscBtn = document.getElementById("sortAscBtn");
const sortDescBtn = document.getElementById("sortDescBtn");
const searchInput = document.getElementById("searchInput");
const statusMessage = document.getElementById("statusMessage");
const usersGrid = document.getElementById("usersGrid");

let allUsers = [];

loadUsersBtn.addEventListener("click", fetchUsers);
searchInput.addEventListener("input", handleSearch);
sortAscBtn.addEventListener("click", () => sortUsers("asc"));
sortDescBtn.addEventListener("click", () => sortUsers("desc"));

async function fetchUsers() {
  try {
    showLoading();
    usersGrid.innerHTML = "";
    disableControls(true);

    const response = await fetch(API_URL);

    if (!response.ok) {
      throw new Error(`Server xətası: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    allUsers = data;

    clearStatus();
    enableControls();
    renderUsers(allUsers);
  } catch (error) {
    showError(`İstifadəçiləri yükləyərkən xəta baş verdi: ${error.message}`);
  }
}

function renderUsers(users) {
  usersGrid.innerHTML = "";

  if (users.length === 0) {
    showEmptyState("No users found");
    return;
  }

  clearStatus();

  users.forEach((user) => {
    const card = document.createElement("div");
    card.className = "user-card";

    const name = escapeHtml(user.name);
    const username = escapeHtml(user.username);
    const email = escapeHtml(user.email);
    const phone = escapeHtml(user.phone);
    const website = escapeHtml(user.website);

    const street = escapeHtml(user.address?.street || "");
    const suite = escapeHtml(user.address?.suite || "");
    const city = escapeHtml(user.address?.city || "");
    const zipcode = escapeHtml(user.address?.zipcode || "");
    const companyName = escapeHtml(user.company?.name || "");
    const catchPhrase = escapeHtml(user.company?.catchPhrase || "");

    card.innerHTML = `
      <div>
        <div class="user-header">
          <div class="user-name">${name}</div>
          <div class="user-username">@${username}</div>
        </div>
        <ul class="user-info">
          <li><strong>Email:</strong> <a href="mailto:${email}">${email}</a></li>
          <li><strong>Phone:</strong> ${phone}</li>
          <li><strong>Website:</strong> <a href="https://${website}" target="_blank" rel="noopener noreferrer">${website}</a></li>
        </ul>
      </div>
      <div>
        <button class="details-btn">Show Details</button>
        <div class="details-section hidden">
          <h4>🏢 Şirkət:</h4>
          <p>${companyName}</p>
          <p><em>"${catchPhrase}"</em></p>
          <h4>📍 Ünvan:</h4>
          <p>${street}, ${suite}</p>
          <p>${city}, ${zipcode}</p>
        </div>
      </div>
    `;

    const detailsBtn = card.querySelector(".details-btn");
    const detailsSection = card.querySelector(".details-section");

    detailsBtn.addEventListener("click", () => {
      const isHidden = detailsSection.classList.contains("hidden");
      if (isHidden) {
        detailsSection.classList.remove("hidden");
        detailsBtn.textContent = "Hide Details";
      } else {
        detailsSection.classList.add("hidden");
        detailsBtn.textContent = "Show Details";
      }
    });

    usersGrid.appendChild(card);
  });
}

function handleSearch(e) {
  const query = e.target.value.trim().toLowerCase();
  const filteredUsers = allUsers.filter((user) =>
    user.name.toLowerCase().includes(query)
  );
  renderUsers(filteredUsers);
}

function sortUsers(order) {
  const query = searchInput.value.trim().toLowerCase();
  let currentList = allUsers.filter((user) =>
    user.name.toLowerCase().includes(query)
  );

  currentList.sort((a, b) => {
    return order === "asc"
      ? a.name.localeCompare(b.name)
      : b.name.localeCompare(a.name);
  });

  renderUsers(currentList);
}

function showLoading() {
  statusMessage.className = "status-msg loading";
  statusMessage.textContent = "Loading...";
}

function showError(msg) {
  statusMessage.className = "status-msg error";
  statusMessage.textContent = msg;
}

function showEmptyState(msg) {
  statusMessage.className = "status-msg empty";
  statusMessage.textContent = msg;
}

function clearStatus() {
  statusMessage.className = "status-msg";
  statusMessage.textContent = "";
}

function enableControls() {
  searchInput.disabled = false;
  sortAscBtn.disabled = false;
  sortDescBtn.disabled = false;
}

function disableControls(keepLoadingBtn = false) {
  searchInput.disabled = true;
  sortAscBtn.disabled = true;
  sortDescBtn.disabled = true;
  if (!keepLoadingBtn) {
    loadUsersBtn.disabled = true;
  }
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
