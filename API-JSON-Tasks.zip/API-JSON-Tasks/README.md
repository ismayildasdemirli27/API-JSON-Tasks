# API & JSON — Practical Tasks Həlləri

Bütün tapşırıqlar Vanilla JavaScript, HTML5 və müasir CSS istifadə olunaraq tələblərə və bonuslara uyğun şəkildə tam həyata keçirilmişdir.

## Qovluq Strukturu

```text
API-JSON-Tasks/
│
├── task-1-user-directory/
│   ├── index.html
│   ├── style.css
│   └── script.js
│
├── task-2-product-catalog/
│   ├── index.html
│   ├── style.css
│   └── script.js
│
└── task-3-post-management/
    ├── index.html
    ├── style.css
    └── script.js
```

---

## Task 1 — User Directory
- **Endpoint:** `GET https://jsonplaceholder.typicode.com/users`
- **Xüsusiyyətlər:**
  - `Load Users` düyməsi ilə istifadəçilərin asinxron yüklənməsi (`async/await`, `fetch`).
  - Dinamik kartlar: Name, Username, Email, Phone, Website.
  - Canlı axtarış (`Search Users` input) və axtarışa uyğun nəticə olmadıqda `No users found` mesajı.
  - `Loading...` və xəta idarəetməsi (`try/catch`, `response.ok`).
  - **Bonus:** İstifadəçiləri adlarına görə A–Z və Z–A sıralama düymələri.
  - **Bonus:** `Show Details` / `Hide Details` düyməsi ilə şirkət və ünvan məlumatlarının açılıb bağlanması.

---

## Task 2 — Product Catalog
- **Endpoint:** DummyJSON Products API
- **Xüsusiyyətlər:**
  - İlk 12 məhsulun yüklənməsi (`limit=12`, `skip=0`).
  - Məhsul kartları: Image, Title, Price, Category, Rating, Stock.
  - Dinamik kateqoriya siyahısı (`https://dummyjson.com/products/categories`) və kateqoriya seçimi filtri.
  - Axtarış (`https://dummyjson.com/products/search?q=...`) debounce ilə.
  - `Load More` düyməsi ilə növbəti 12 məhsulun paginasiya ilə yüklənməsi.
  - Loading, error və empty state-lər.
  - **Bonus:** Qiymətə görə artan və azalan çeşidləmə (`Sort by price`).
  - **Bonus:** Stokda olmayan məhsullara `Out of Stock` bildirişi.
  - **Bonus:** `View Details` düyməsi ilə açılan modal pəncərə.

---

## Task 3 — Post Management Dashboard
- **Endpoint:** `https://jsonplaceholder.typicode.com/posts`
- **Xüsusiyyətlər:**
  - **Read (GET):** İlk 10 postun yüklənməsi və göstərilməsi.
  - **Create (POST):** Yeni post yaratmaq üçün form, validasiya (Title və Body boş ola bilməz), API POST sorğusu və lokal array-in yenilənməsi.
  - **Update (PUT):** `Edit` düyməsi ilə post məlumatlarının formaya doldurulması, PUT sorğusu və səhifədə canlı yenilənmə.
  - **Delete (DELETE):** Təsdiq pəncərəsi (`confirm`), API DELETE sorğusu və siyahıdan silinmə.
  - Loading və status bildirişləri (Toast alert-lər).
  - **Bonus:** `PATCH` metodu ilə yalnız Title yenilənməsi.
  - **Bonus:** Fetch və Axios müqayisə cədvəli və izahı.

---

## Yoxlamaq üçün
İstənilən tapşırığın `index.html` faylını birbaşa brauzerdə açaraq və ya Live Server vasitəsilə işə sala bilərsiniz.
